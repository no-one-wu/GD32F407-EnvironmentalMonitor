/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-19     lp666       the first version
 */

#include "all_task.h"
#include "smg.h"


//int SMG_1[16] = { 0X3F, 0X06, 0X5B, 0X4F, 0X66, 0X6D, 0X7D, 0X07, 0X7F, 0X6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71 };
void RW5_thread1(void)
{

    Voice_Config_Init();

    voice_rouse();
    rt_thread_mdelay(500);
    voice_broadcast(10);
    while(1)
    {





        SMG_DRIVE(SMG[1],1);
        rt_thread_mdelay(12);
        SMG_DRIVE(SMG[9],2);
        rt_thread_mdelay(12);
        if (Taskshutdown != 5) {
            SMG_OFF();
            return;  // 退出任务
        }

//        rt_thread_mdelay(1000);
    }
}


void task_5(void)
{
    Smg_init();
    Taskshutdown = 5;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW5_thread1);

}

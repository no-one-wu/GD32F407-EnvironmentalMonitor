/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"


void RW6_thread1(void)
{


    while(1)
    {

        pwm_green_init(task_6buff[0]);

        if (Taskshutdown != 6) {

            pwm_green_init(0);
            return;  // 退出任务
        }

        rt_thread_mdelay(20);
    }
}


void task_6(void)
{

    Taskshutdown = 6;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW6_thread1);

}

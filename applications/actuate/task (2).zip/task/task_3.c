#include "all_task.h"
#include "DHT11.h"

#include "actuate/ds1302/ds1302.h"
#include "Ultrasonic.h"

#include "led.h"

#include "beep.h"
// 示例：构造要发送的数据并写入 LCD 设备
//void send_to_nextion_2(rt_device_t lcd_dev, const char* text)
//{
//
//
//    const char* prefix = "page2.t2.txt=\"";
//    const char* suffix = "\"";
//
//
//    size_t prefix_len = strlen(prefix);
//    size_t text_len   = strlen(text);
//    size_t suffix_len = strlen(suffix);
//
//
//    size_t total_len = prefix_len + text_len + suffix_len + 3 /* 0xFF */ + 1 /* '\0' */;
//
//
//    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
//    if (!buffer)
//    {
//        rt_kprintf("malloc failed!\n");
//        return;
//    }
//    memset(buffer, 0, total_len);  // 清零
//
//
//    memcpy(buffer, prefix, prefix_len);
//
//    memcpy(buffer + prefix_len, text, text_len);
//
//    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);
//
//
//    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
//    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
//    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;
//
//
//    buffer[prefix_len + text_len + suffix_len + 3] = '\0';
//
//
//    size_t write_len = prefix_len + text_len + suffix_len + 3;  // 不带末尾 '\0'
//    rt_device_write(lcd_dev, 0, buffer, write_len);
//
//
//    rt_kprintf("Send to Nextion(含0xFFx3): %s\n", buffer);
//
//    rt_free(buffer);
//}


void RW3_thread1(void)
{

    beep_init();

    rt_uint8_t buffer_5[64];
    rt_uint8_t buffer_6[64];
    int distance = 0;

    while(1)
    {

        distance = ranging_more();
        rt_kprintf("距离%d\n",distance);

        if(distance > 200){
            int a = 0;
            LEDx_Set_Status(OFF);
//            rt_thread_mdelay(500);
            LEDx_Set_Status(greenRGB_ON);
//            send_to_nextion_3(lcd_dev,0);
            snprintf((char*)buffer_5, sizeof(buffer_5), "page3.p0.pic=%d", a);

            int data_len = strlen((char*)buffer_5); // 获取当前数据的长度
            if (data_len + 3 < sizeof(buffer_5)) { // 确保空间足够
                buffer_5[data_len] = 0xff;
                buffer_5[data_len + 1] = 0xff;
                buffer_5[data_len + 2] = 0xff;
                data_len += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_5, data_len);  // 使用实际数据长度
            rt_kprintf("写入图片数据: %s\n", buffer_5);  // 调试输出



            snprintf((char*)buffer_6, sizeof(buffer_6), "page3.t3.txt=\"%d\"", distance);

            int data_len_1 = strlen((char*)buffer_6); // 获取当前数据的长度
            if (data_len_1 + 3 < sizeof(buffer_6)) { // 确保空间足够
                buffer_6[data_len_1] = 0xff;
                buffer_6[data_len_1 + 1] = 0xff;
                buffer_6[data_len_1 + 2] = 0xff;
                data_len_1 += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_6, data_len_1);  // 使用实际数据长度
            rt_kprintf("写入距离数据: %s\n", buffer_6);  // 调试输出
            rt_pin_write(rt_pin_get("PC.12"), PIN_LOW);
        }
        else if(distance>100 && distance <200){

            int a = 1;
            LEDx_Set_Status(OFF);
//            rt_thread_mdelay(500);
            LEDx_Set_Status(yellowRGB);
//            send_to_nextion_3(lcd_dev,0);
            snprintf((char*)buffer_5, sizeof(buffer_5), "page3.p0.pic=%d", a);

            int data_len = strlen((char*)buffer_5); // 获取当前数据的长度
            if (data_len + 3 < sizeof(buffer_5)) { // 确保空间足够
                buffer_5[data_len] = 0xff;
                buffer_5[data_len + 1] = 0xff;
                buffer_5[data_len + 2] = 0xff;
                data_len += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_5, data_len);  // 使用实际数据长度
            rt_kprintf("写入图片数据: %s\n", buffer_5);  // 调试输出



            snprintf((char*)buffer_6, sizeof(buffer_6), "page3.t3.txt=\"%d\"", distance); //"page2.t8.txt=\"%d\""

            int data_len_1 = strlen((char*)buffer_6); // 获取当前数据的长度
            if (data_len_1 + 3 < sizeof(buffer_6)) { // 确保空间足够
                buffer_6[data_len_1] = 0xff;
                buffer_6[data_len_1 + 1] = 0xff;
                buffer_6[data_len_1 + 2] = 0xff;
                data_len_1 += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_6, data_len_1);  // 使用实际数据长度
            rt_kprintf("写入距离数据: %s\n", buffer_6);  // 调试输出
            rt_pin_write(rt_pin_get("PC.12"), PIN_LOW);
        }

        else if(distance<100)
        {
            int a = 2;
            LEDx_Set_Status(OFF);
//            rt_thread_mdelay(500);
            LEDx_Set_Status(redRGB_ON);


//            send_to_nextion_3(lcd_dev,0);
            snprintf((char*)buffer_5, sizeof(buffer_5), "page3.p0.pic=%d", a);

            int data_len = strlen((char*)buffer_5); // 获取当前数据的长度
            if (data_len + 3 < sizeof(buffer_5)) { // 确保空间足够
                buffer_5[data_len] = 0xff;
                buffer_5[data_len + 1] = 0xff;
                buffer_5[data_len + 2] = 0xff;
                data_len += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_5, data_len);  // 使用实际数据长度
            rt_kprintf("写入图片数据: %s\n", buffer_5);  // 调试输出



            snprintf((char*)buffer_6, sizeof(buffer_6), "page3.t3.txt=\"%d\"", distance);

            int data_len_1 = strlen((char*)buffer_6); // 获取当前数据的长度
            if (data_len_1 + 3 < sizeof(buffer_6)) { // 确保空间足够
                buffer_6[data_len_1] = 0xff;
                buffer_6[data_len_1 + 1] = 0xff;
                buffer_6[data_len_1 + 2] = 0xff;
                data_len_1 += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_6, data_len_1);  // 使用实际数据长度
            rt_kprintf("写入距离数据: %s\n", buffer_6);  // 调试输出

            rt_pin_write(rt_pin_get("PC.12"), PIN_HIGH);
        }
        else {

            rt_kprintf("数据错误！");
        }



        if (Taskshutdown != 3) {
            rt_pin_write(rt_pin_get("PC.12"), PIN_LOW);
            LEDR_reset
            LEDG_reset
            LEDB_reset
            return;  // 退出任务
        }

        rt_thread_mdelay(1000);
    }
}


void task_3(void)
{

    LED_RGB_init();
    Taskshutdown = 3;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW3_thread1);

}

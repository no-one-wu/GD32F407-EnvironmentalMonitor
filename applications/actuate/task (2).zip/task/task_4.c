/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-11     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"
#include "bkrc_voice.h"
#include "actuate/paj7620u2/paj7620u2_iic.h"

#include "Ultrasonic.h"



//void send_to_nextion_4(rt_device_t lcd_dev, const char* text)
//{
//
//
//    const char* prefix = "page4.t1.txt=\"";
//    const char* suffix = "\"";
//
//
//    size_t prefix_len = strlen(prefix);
//    size_t text_len   = strlen(text);
//    size_t suffix_len = strlen(suffix);
//
//
//    size_t total_len = prefix_len + text_len + suffix_len + 3 /* 0xFF */ + 1 /* '\0' */;
//
//
//    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
//    if (!buffer)
//    {
//        rt_kprintf("malloc failed!\n");
//        return;
//    }
//    memset(buffer, 0, total_len);  // 清零
//
//
//    memcpy(buffer, prefix, prefix_len);
//
//    memcpy(buffer + prefix_len, text, text_len);
//
//    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);
//
//
//    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
//    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
//    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;
//
//
//    buffer[prefix_len + text_len + suffix_len + 3] = '\0';
//
//
//    size_t write_len = prefix_len + text_len + suffix_len + 3;  // 不带末尾 '\0'
//    rt_device_write(lcd_dev, 0, buffer, write_len);
//
//
//    rt_kprintf("Send to Nextion(含0xFFx3): %s\n", buffer);
//
//    rt_free(buffer);
//}
rt_uint8_t buffer_3[64];

void  RW4_thread1(void)
{

    int distance_1 = 0;
    float a = 0;

    while(1)
    {


        distance_1 = ranging_more();
        a = (float)distance_1;
        rt_kprintf("距离%d\n",distance_1);


        snprintf((char*)buffer_3, sizeof(buffer_3), "page4.t1.txt=\"%.1f\"", a);

        int data_len = strlen((char*)buffer_3); // 获取当前数据的长度
        if (data_len + 3 < sizeof(buffer_3)) { // 确保空间足够
            buffer_3[data_len] = 0xff;
            buffer_3[data_len + 1] = 0xff;
            buffer_3[data_len + 2] = 0xff;
            data_len += 3; // 更新实际数据长度
        } else {
            rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
            return;
        }

        rt_device_write(lcd_dev, 0, buffer_3, data_len);  // 使用实际数据长度
        rt_kprintf("写入距离数据: %s\n", buffer_3);  // 调试输出

        if(distance_1 > 200)
        {

            pwm_white_init(90);
        }
        else if(distance_1 >= 100 && distance_1 <= 200)
        {
            pwm_white_init(50);

        }
        else {
            pwm_white_init(10);

        }




        if (Taskshutdown == 0)
        {
            pwm_white_init(0);
            return;  // 退出任务
        }

        rt_thread_mdelay(20);
    }

}


void task_4(void)
{
    Taskshutdown = 4;

    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW4_thread1);

}

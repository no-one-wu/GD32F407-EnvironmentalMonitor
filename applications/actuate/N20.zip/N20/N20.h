///*
// * Copyright (c) 2006-2021, RT-Thread Development Team
// *
// * SPDX-License-Identifier: Apache-2.0
// *
// * Change Logs:
// * Date           Author       Notes
// * 2025-03-03     lp666       the first version
// */
//#ifndef APPLICATIONS_ACTUATE_N20_N20_H_
//#define APPLICATIONS_ACTUATE_N20_N20_H_
//void motor_init(void);
//void motor_set_speed(int speed);
//void motor_stop(void);
//int get_encoder_count(void);
//void motor_test(void);
//#endif /* APPLICATIONS_ACTUATE_N20_N20_H_ */

///*
// * Copyright (c) 2006-2021, RT-Thread Development Team
// *
// * SPDX-License-Identifier: Apache-2.0
// *
// * Change Logs:
// * Date           Author       Notes
// * 2025-03-03     lp666       the first version
// */
//
//
//#include <rtthread.h>
//#include <rtdevice.h>
//#include "N20.h"
//#define ENC_DEV_NAME   "pulse4"   /* 编码器设备名称 */
//
//void encoder_init(void)
//{
//    rt_device_t enc_dev = rt_device_find(ENC_DEV_NAME);
//    if (enc_dev == RT_NULL)
//    {
//        rt_kprintf("Encoder device not found: %s\n", ENC_DEV_NAME);
//        return;
//    }
//
//    if (rt_device_open(enc_dev, RT_DEVICE_OFLAG_RDONLY) != RT_EOK)
//    {
//        rt_kprintf("Failed to open encoder device!\n");
//        return;
//    }
//
//    /* 清除编码器计数 */
//    rt_device_control(enc_dev, PULSE_ENCODER_CMD_CLEAR_COUNT, RT_NULL);
//    rt_kprintf("Encoder initialized: %s\n", ENC_DEV_NAME);
//}
////INIT_APP_EXPORT(encoder_init);
//
//
//int get_encoder_count(void)
//{
//    rt_int32_t count = 0;
//    rt_device_t enc_dev = rt_device_find(ENC_DEV_NAME);
//
//    if (enc_dev == RT_NULL)
//    {
//        rt_kprintf("Encoder not found!\n");
//        return 0;
//    }
//
//    rt_device_read(enc_dev, 0, &count, 1);  // 读取计数值
//    return count;
//}
//
//
//
//void motor_test(void)
//{
//    /* 初始化电机 */
//    motor_init();
//    rt_kprintf("1");
//    rt_thread_mdelay(100);  // 等待初始化完成
//
//    /* 初始化编码器 */
//    encoder_init();
//    rt_thread_mdelay(100);
//
//    /* 清零编码器 */
//    rt_device_t enc_dev = rt_device_find("pulse4");
//    if (enc_dev)
//    {
//        rt_device_control(enc_dev, PULSE_ENCODER_CMD_CLEAR_COUNT, RT_NULL);
//    }
//
//    /* 启动电机 */
//    rt_kprintf("Motor running at speed: %d\n", 10000);
//    motor_set_speed(10000);
//
//    /* 记录初始时间和编码器初始值 */
//    rt_uint32_t start_time = rt_tick_get();
//    rt_thread_mdelay(3000); // 运行一段时间
//    rt_uint32_t end_time = rt_tick_get();
//
//    /* 获取编码器的最终计数 */
//    int encoder_count = get_encoder_count();
//    rt_kprintf("Encoder count: %d\n", encoder_count);
//
//    /* 计算速度 (假设编码器每转一圈 1000 脉冲) */
//    float elapsed_time = (end_time - start_time) * 1000.0 / RT_TICK_PER_SECOND; // ms 转换为秒
//    float speed_rpm = (encoder_count / 1000.0) * (60000.0 / elapsed_time); // 转换为 RPM
//    rt_kprintf("Motor Speed: %.2f RPM\n", speed_rpm);
//
//    /* 停止电机 */
//    motor_stop();
//    rt_kprintf("Motor stopped.\n");
//}

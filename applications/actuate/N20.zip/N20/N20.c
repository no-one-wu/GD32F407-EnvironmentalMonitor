//#include <rtthread.h>
//#include <rtdevice.h>
//#include <board.h>
//
///* 定义 PWM 相关参数 */
//#define PWM_DEV_NAME   "pwm2"   /* PWM 设备名称 */
//#define PWM_CHANNEL1   1        /* PWM 通道1（M_IN1） */
//#define PWM_CHANNEL2   2        /* PWM 通道2（M_IN2） */
//
//static rt_device_t pwm_dev = RT_NULL;  /* PWM 设备句柄 */
//
///* 初始化电机控制 */
//void motor_init(void)
//{
//    pwm_dev = rt_device_find(PWM_DEV_NAME);
//    if (pwm_dev == RT_NULL)
//    {
//        rt_kprintf("PWM device %s not found!\n", PWM_DEV_NAME);
//        return;
//    }
//
//    /* 启动 PWM 设备 */
//    rt_pwm_enable(pwm_dev, PWM_CHANNEL1);
//    rt_pwm_enable(pwm_dev, PWM_CHANNEL2);
//
//    /* 初始化占空比为 0，防止电机误动作 */
//    rt_pwm_set(pwm_dev, PWM_CHANNEL1, 10000, 0);
//    rt_pwm_set(pwm_dev, PWM_CHANNEL2, 10000, 0);
//
//}
//
///* 设置电机速度 */
//void motor_set_speed(int speed)
//{
//    if (pwm_dev == RT_NULL)
//    {
//        rt_kprintf("Motor not initialized!\n");
//        return;
//    }
//
//
//
//    /* speed > 0，正转；speed < 0，反转 */
//    if (speed > 0)
//    {
//        rt_pwm_set(pwm_dev, PWM_CHANNEL1, 10000, speed);  // 设置 M_IN1
//        rt_pwm_set(pwm_dev, PWM_CHANNEL2, 10000, 0);      // 关闭 M_IN2
//    }
//    else if (speed < 0)
//    {
//        rt_pwm_set(pwm_dev, PWM_CHANNEL1, 10000, 0);      // 关闭 M_IN1
//        rt_pwm_set(pwm_dev, PWM_CHANNEL2, 10000, -speed); // 设置 M_IN2
//    }
//    else
//    {
//        motor_stop();
//    }
//}
//
///* 停止电机 */
//void motor_stop(void)
//{
//    if (pwm_dev == RT_NULL)
//    {
//        rt_kprintf("Motor not initialized!\n");
//        return;
//    }
//
//    rt_pwm_set(pwm_dev, PWM_CHANNEL1, 10000, 0);
//    rt_pwm_set(pwm_dev, PWM_CHANNEL2, 10000, 0);
//}

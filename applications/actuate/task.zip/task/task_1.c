/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"



void RW1_thread1(void)
{



    LEDx_Set_Status(redRGB_ON);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(OFF);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(greenRGB_ON);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(OFF);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(blueRGB_ON);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(OFF);
    rt_thread_mdelay(1000);

    LEDx_Set_Status(redRGB_ON);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(OFF);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(greenRGB_ON);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(OFF);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(blueRGB_ON);
    rt_thread_mdelay(1000);
    LEDx_Set_Status(OFF);
    rt_thread_mdelay(1000);


    while(1)
    {



        if (Taskshutdown != 1) {
            BEEP_OFF;

            LEDR_reset;
            LEDG_reset;
            LEDB_reset;

            return;  // 退出任务
        }
//        else {
//
//
//        }

        rt_thread_mdelay(1000);
    }
}


void task_1(void)
{

    LED_RGB_init();

    rt_mb_send(task1_thread_mailbox,RW1_thread1);


}



/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"


void RW7_thread1(void)
{
    beep_init();

    beep_music(1,500);
    beep_music(2,500);
    beep_music(3,500);
    beep_music(1,500);

    beep_music(2,500);
    beep_music(5,500);
    beep_music(5,500);
    beep_music(0,0);
    rt_thread_mdelay(500);

    beep_music(3,500);
    beep_music(6,250);
    beep_music(6,250);
    beep_music(6,500);
    beep_music(6,500);

    beep_music(5,500);
    beep_music(5,500);
    beep_music(3,500);
    beep_music(0,0);
    rt_thread_mdelay(500);

    beep_music(1,750);
    beep_music(1,250);
    beep_music(1,500);
    beep_music(6,250);
    beep_music(6,250);

    beep_music(5,500);
    beep_music(3,500);
    beep_music(5,500);
    beep_music(0,0);
    rt_thread_mdelay(500);

    beep_music(2,250);
    beep_music(2,500);
    beep_music(3,250);
    beep_music(3,250);
    beep_music(2,250);
    beep_music(1,250);
    beep_music(3,250);

    beep_music(2,1000);

    beep_music(1,500);
    beep_music(2,500);
    beep_music(3,500);
    beep_music(1,500);

    beep_music(2,500);
    beep_music(5,250);
    beep_music(5,250);
    beep_music(5,500);
    beep_music(0,0);
    rt_thread_mdelay(500);

    beep_music(3,500);
    beep_music(6,500);
    beep_music(6,500);
    beep_music(1,500);

    beep_music(7,500);
    beep_music(6,500);
    beep_music(5,500);
    beep_music(0,0);
    rt_thread_mdelay(500);

    beep_music(1,750);
    beep_music(1,250);
    beep_music(1,500);
    beep_music(6,500);

    beep_music(5,500);
    beep_music(5,500);
    beep_music(3,500);
    beep_music(0,0);
    rt_thread_mdelay(500);

    beep_music(2,250);
    beep_music(2,500);
    beep_music(2,250);
    beep_music(3,250);
    beep_music(2,250);
    beep_music(1,250);
    beep_music(2,250);

    beep_music(0,0);

    while(1)
    {








        if (Taskshutdown != 7) {

            BEEP_OFF;
            return;  // 退出任务
        }

        rt_thread_mdelay(1000);
    }
}


void task_7(void)
{

    rt_mb_send(task1_thread_mailbox,RW7_thread1);

}

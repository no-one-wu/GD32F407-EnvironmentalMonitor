/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"


void RW6_thread1(void)
{
    C1016_Init();
    uint16_t i = 0;

    while(1)
    {
//        C1016_Enroll(3);

        i = C1016_Identify();

        if(i == 1)
        {
            rt_kprintf("1");
            step_28byj48_angles(90,1);

        }

        else if(i == 2)
        {
            rt_kprintf("2");
            step_28byj48_angles(180,1);


        }

        else if(i == 3)
        {
            rt_kprintf("3");
            step_28byj48_angles(270,1);
        }


        if (Taskshutdown != 6) {


            return;  // 退出任务
        }

        rt_thread_mdelay(1000);
    }
}


void task_6(void)
{
//    StepperMotor_init();

    rt_mb_send(task1_thread_mailbox,RW6_thread1);

}

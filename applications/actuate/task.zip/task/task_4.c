/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-11     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"
#include "bkrc_voice.h"
#include "actuate/paj7620u2/paj7620u2_iic.h"
#define GES_UP              BIT(0) //向上
#define GES_DOWN            BIT(1) //向下
#define GES_LEFT            BIT(2) //向左
#define GES_RIGHT           BIT(3) //向右
#define GES_FORWARD         BIT(4) //向前
#define GES_BACKWARD        BIT(5) //向后
#define GES_CLOCKWISE       BIT(6) //顺时针
#define GES_ANTI_CLOCKWISE  BIT(7) //逆时针
#define GES_WAVE            BIT(8) //挥动
#define BIT(x) 1<<(x)
#define PAJ_GET_INT_FLAG1          0X43 //获取手势检测中断标志寄存器1(获取手势结果)




void send_to_nextion_4(rt_device_t lcd_dev, const char* text)
{


    const char* prefix = "page4.t1.txt=\"";
    const char* suffix = "\"";


    size_t prefix_len = strlen(prefix);
    size_t text_len   = strlen(text);
    size_t suffix_len = strlen(suffix);


    size_t total_len = prefix_len + text_len + suffix_len + 3 /* 0xFF */ + 1 /* '\0' */;


    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
    if (!buffer)
    {
        rt_kprintf("malloc failed!\n");
        return;
    }
    memset(buffer, 0, total_len);  // 清零


    memcpy(buffer, prefix, prefix_len);

    memcpy(buffer + prefix_len, text, text_len);

    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);


    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;


    buffer[prefix_len + text_len + suffix_len + 3] = '\0';


    size_t write_len = prefix_len + text_len + suffix_len + 3;  // 不带末尾 '\0'
    rt_device_write(lcd_dev, 0, buffer, write_len);


    rt_kprintf("Send to Nextion(含0xFFx3): %s\n", buffer);

    rt_free(buffer);
}

void RW4_thread1(void)
{
    Voice_Config_Init();

    voice_rouse();
    rt_thread_mdelay(500);
//    voice_broadcast(1);

    while(1)
    {


        unsigned char gesture_result = GS_Read_Byte(PAJ_GET_INT_FLAG1);

        if (gesture_result & GES_UP) {
            rt_kprintf("指令: 向上\n");
            voice_broadcast(1);
            send_to_nextion_4(lcd_dev,"向上");
        } else if (gesture_result & GES_DOWN) {
            rt_kprintf("指令: 向下\n");
            voice_broadcast(2);
            send_to_nextion_4(lcd_dev,"向下");
        } else if (gesture_result & GES_LEFT) {
            rt_kprintf("指令: 向左\n");
            voice_broadcast(3);
            send_to_nextion_4(lcd_dev,"向左");
        } else if (gesture_result & GES_RIGHT) {
            rt_kprintf("指令: 向右\n");
            voice_broadcast(4);
            send_to_nextion_4(lcd_dev,"向右");
        } else if (gesture_result & GES_FORWARD) {
            rt_kprintf("指令: 向前\n");
            voice_broadcast(5);
            send_to_nextion_4(lcd_dev,"向前");
        } else if (gesture_result & GES_BACKWARD) {
            rt_kprintf("指令: 向后\n");
            voice_broadcast(6);
            send_to_nextion_4(lcd_dev,"向后");
        } else if (gesture_result & GES_CLOCKWISE) {
            rt_kprintf("指令: 顺时针\n");
            voice_broadcast(7);
            send_to_nextion_4(lcd_dev,"顺时针");
        } else if (gesture_result & GES_ANTI_CLOCKWISE) {
            rt_kprintf("指令: 逆时针\n");
            voice_broadcast(8);
            send_to_nextion_4(lcd_dev,"逆时针");
        } else if (gesture_result & GES_WAVE) {
            rt_kprintf("指令: 挥动\n");
            voice_broadcast(9);
            send_to_nextion_4(lcd_dev,"挥动");
        }
//        else {
//            rt_kprintf("数据错误!");
//        }





        if (Taskshutdown != 4) {


            return;  // 退出任务
        }

        rt_thread_mdelay(1000);
    }
}


void task_4(void)
{
    PAJ7620_Init();
    rt_mb_send(task1_thread_mailbox,RW4_thread1);

}

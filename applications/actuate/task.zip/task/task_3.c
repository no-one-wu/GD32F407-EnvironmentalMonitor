#include "all_task.h"
#include "DHT11.h"

#include "actuate/ds1302/ds1302.h"




void RW3_thread1(void)
{


    rt_uint8_t buffer_3[64];


    while(1)
    {

        DS1302_ReadTime();

        rt_kprintf("20%d年%d月%d日 %d时%d分%d秒 星期%d\n",DS1302_Time[0],DS1302_Time[1],DS1302_Time[2],DS1302_Time[3],DS1302_Time[4],DS1302_Time[5],DS1302_Time[6]);




        if(DS1302_Time[5]<20){
            int a = 0;
//            send_to_nextion_3(lcd_dev,0);
            snprintf((char*)buffer_3, sizeof(buffer_3), "page3.p0.pic=%d", a);

            int data_len = strlen((char*)buffer_3); // 获取当前数据的长度
            if (data_len + 3 < sizeof(buffer_3)) { // 确保空间足够
                buffer_3[data_len] = 0xff;
                buffer_3[data_len + 1] = 0xff;
                buffer_3[data_len + 2] = 0xff;
                data_len += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_3, data_len);  // 使用实际数据长度
            rt_kprintf("写入距离数据: %s\n", buffer_3);  // 调试输出
        }
        else if(DS1302_Time[5]>=20&&DS1302_Time[5]<40){

//            send_to_nextion_3(lcd_dev,1);
            int a = 1;
            snprintf((char*)buffer_3, sizeof(buffer_3), "page3.p0.pic=%d", a);

            int data_len = strlen((char*)buffer_3); // 获取当前数据的长度
            if (data_len + 3 < sizeof(buffer_3)) { // 确保空间足够
                buffer_3[data_len] = 0xff;
                buffer_3[data_len + 1] = 0xff;
                buffer_3[data_len + 2] = 0xff;
                data_len += 3; // 更新实际数据长度
            } else {
                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
                return;
            }

            rt_device_write(lcd_dev, 0, buffer_3, data_len);  // 使用实际数据长度
            rt_kprintf("写入距离数据: %s\n", buffer_3);  // 调试输出
        }
        else {

            rt_kprintf("数据错误！");
        }



        if (Taskshutdown != 3) {


            return;  // 退出任务
        }

        rt_thread_mdelay(1000);
    }
}


void task_3(void)
{
    DS1302_Init();
    rt_mb_send(task1_thread_mailbox,RW3_thread1);

}

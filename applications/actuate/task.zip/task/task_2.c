/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"
#include "DHT11.h"
#include "bkrc_voice.h"
#include "Ultrasonic.h"



// 示例：构造要发送的数据并写入 LCD 设备
void send_to_nextion_2(rt_device_t lcd_dev, const char* text)
{


    const char* prefix = "page2.t2.txt=\"";
    const char* suffix = "\"";


    size_t prefix_len = strlen(prefix);
    size_t text_len   = strlen(text);
    size_t suffix_len = strlen(suffix);


    size_t total_len = prefix_len + text_len + suffix_len + 3 /* 0xFF */ + 1 /* '\0' */;


    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
    if (!buffer)
    {
        rt_kprintf("malloc failed!\n");
        return;
    }
    memset(buffer, 0, total_len);  // 清零


    memcpy(buffer, prefix, prefix_len);

    memcpy(buffer + prefix_len, text, text_len);

    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);


    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;


    buffer[prefix_len + text_len + suffix_len + 3] = '\0';


    size_t write_len = prefix_len + text_len + suffix_len + 3;  // 不带末尾 '\0'
    rt_device_write(lcd_dev, 0, buffer, write_len);


    rt_kprintf("Send to Nextion(含0xFFx3): %s\n", buffer);

    rt_free(buffer);
}


static void RW2_thread1(void)
{

    // 检查 lcd_dev 是否初始化
//       if (lcd_dev == RT_NULL) {
//           rt_kprintf("LCD device not initialized!\n");
//           return;  // 如果 LCD 设备没有初始化，退出任务
//       }
//
//    int temp = 0,humi = 0;
//    int distance = 0;
//    float a = 0,b = 0;//c = 0
//    rt_uint8_t buffer_3[64];
//    rt_uint8_t buffer_1[64];
//    rt_uint8_t buffer_2[64];

    Voice_Config_Init();

    voice_rouse();
    rt_thread_mdelay(500);
    voice_broadcast(10);
    unsigned char sum = 0;
//    send_to_nextion_2(lcd_dev, "知识改变命运");  // 干燥
    while(1){


        if (Taskshutdown != 2) {
            rt_kprintf("Exiting task 1...\n");
            return;  // 退出任务
        }

        else
        {

            sum =  Voice_Drive();
            rt_kprintf("%d",sum);
            if(sum == 1)
            {
                rt_kprintf("1");
                send_to_nextion_2(lcd_dev, "知识改变命运");  // 干燥
            }
            else if(sum == 2)
            {
                send_to_nextion_2(lcd_dev, "技能成就未来");  // 干燥
            }
            else if(sum == 3)
            {
                send_to_nextion_2(lcd_dev, "实践锻炼能力");  // 干燥
            }
            else if(sum == 4){
                send_to_nextion_2(lcd_dev, "比赛彰显才智");  // 干燥
            }


//            distance = ranging_once();
//            a = (float)distance;
////
////
//            if(DHT11_REC_Data(&temp,&humi)==1){
//                rt_kprintf("温度:%d湿度:%d\n",temp,humi);
//                b = (float)temp;
////                c = (float)humi;
//            }
//            else {
//                rt_kprintf("读取设备失败！");
//                return;
//            }
////
//
//
//
//
//            snprintf((char*)buffer_3, sizeof(buffer_3), "page2.t7.txt=\"%.1f\"", a);
//
//            int data_len = strlen((char*)buffer_3); // 获取当前数据的长度
//            if (data_len + 3 < sizeof(buffer_3)) { // 确保空间足够
//                buffer_3[data_len] = 0xff;
//                buffer_3[data_len + 1] = 0xff;
//                buffer_3[data_len + 2] = 0xff;
//                data_len += 3; // 更新实际数据长度
//            } else {
//                rt_kprintf("1Buffer overflow risk, not adding 0xFF bytes!\n");
//                return;
//            }
//
//
//            snprintf((char*)buffer_1, sizeof(buffer_1), "page2.t8.txt=\"%d\"", humi);
//
//
//            int data_len_1 = strlen((char*)buffer_1); // 获取当前数据的长度
//            if (data_len_1 + 3 < sizeof(buffer_1)) { // 确保空间足够
//                buffer_1[data_len_1] = 0xff;
//                buffer_1[data_len_1 + 1] = 0xff;
//                buffer_1[data_len_1 + 2] = 0xff;
//
//                data_len_1 += 3; // 更新实际数据长度
//            } else {
//                rt_kprintf("2Buffer overflow risk, not adding 0xFF bytes!\n");
//                return;
//            }
////
//
//            snprintf((char*)buffer_2, sizeof(buffer_2), "page2.t6.txt=\"%.1f\"", b);
////
//
//            int data_len_2 = strlen((char*)buffer_2); // 获取当前数据的长度
//            if (data_len_2 + 3 < sizeof(buffer_2)) { // 确保空间足够
//                buffer_2[data_len_2] = 0xff;
//                buffer_2[data_len_2 + 1] = 0xff;
//                buffer_2[data_len_2 + 2] = 0xff;
//
//                data_len_2 += 3; // 更新实际数据长度
//            } else {
//                rt_kprintf("3Buffer overflow risk, not adding 0xFF bytes!\n");
//                return;
//            }
////
////
////            // 将数据写入 LCD
//            rt_device_write(lcd_dev, 0, buffer_3, data_len);  // 使用实际数据长度
//            rt_kprintf("写入距离数据: %s\n", buffer_3);  // 调试输出
////
//            rt_device_write(lcd_dev, 0, buffer_1, data_len_1);  // 使用实际数据长度
//            rt_kprintf("写入湿度数据: %s\n", buffer_1);  // 调试输出
//
//            rt_device_write(lcd_dev, 0, buffer_2, data_len_2);  // 使用实际数据长度
//            rt_kprintf("写入温度: %s\n", buffer_2);  // 调试输出
//
//
//            if (humi < 40)
//            {
//                send_to_nextion_2(lcd_dev, "环境湿度干燥");  // 干燥
//            }
//            else if (humi >= 40  && humi <= 70)
//            {
//                send_to_nextion_2(lcd_dev, "环境湿度较差");  // 较差
//            }
//            else
//            {
//                send_to_nextion_2(lcd_dev, "环境湿度良好");  // 良好
//            }
//
//            rt_thread_mdelay(2000);



        }

        rt_thread_mdelay(1000);

    }
}


void task_2(void)
{


    rt_mb_send(task1_thread_mailbox,RW2_thread1);

}

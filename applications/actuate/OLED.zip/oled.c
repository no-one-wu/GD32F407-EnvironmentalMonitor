#include "oled.h"
#include "oledfont.h"
#include "stdio.h"
#include "rtthread.h"
#include <rtdevice.h>

#define OLED_I2C_BUS_NAME          "i2c1"  /* 传感器连接的I2C总线设备名称 */
static struct rt_i2c_bus_device *i2c1_bus = RT_NULL;

/**************************************************************
 *功  能：OLED端口引脚初始化
 *参  数: 无
 *返回值: 无
 **************************************************************/
void OLED_Hardware_Init(void)
{
    /* 查找I2C总线设备，获取I2C总线设备句柄 */
    if (i2c1_bus == RT_NULL)
    {
        i2c1_bus = (struct rt_i2c_bus_device *) rt_device_find(OLED_I2C_BUS_NAME);
        if (i2c1_bus == RT_NULL)
        {
            rt_kprintf("can't find %s device!\n", OLED_I2C_BUS_NAME);
        }
    }
}

/**************************************************************
 *功  能：OLED输入数据
 *参  数：dat 数据 cmd 命令
 *返回值：无
 **************************************************************/
void OLED_WR_Byte(uint8_t dat, uint8_t cmd_or_data)
{

    struct rt_i2c_msg msgs;
    uint8_t tx_buf[2] = { cmd_or_data, dat };

    msgs.addr = I2C_OLED >> 1;
    msgs.flags = RT_I2C_WR;
    msgs.buf = tx_buf;
    msgs.len = 2;
    /* 调用I2C设备接口传输数据 */
    rt_i2c_transfer(i2c1_bus, &msgs, 1);

//    IIC_Start();
//    IIC_Send_Byte(I2C_OLED);
//    IIC_Wait_Ack();
//    IIC_Send_Byte(cmd_or_data);
//    IIC_Wait_Ack();
//    IIC_Send_Byte(dat);
//    IIC_Wait_Ack();
//    IIC_Stop();
}

void OLED_WR_Len(uint8_t *dat, uint8_t len)
{

    struct rt_i2c_msg msgs;

    msgs.addr = I2C_OLED >> 1;
    msgs.flags = RT_I2C_WR;
    msgs.buf = dat;
    msgs.len = len;
    /* 调用I2C设备接口传输数据 */
    rt_i2c_transfer(i2c1_bus, &msgs, 1);
}

/**************************************************************
 *功  能：设置OLED屏光标位置
 *参  数：x：横坐标   y：纵坐标
 *返回值：无
 **************************************************************/
void OLED_Set_Pos(unsigned char x, unsigned char y)
{
    OLED_WR_Byte(0xb0 + y, IIC_OLED_CMD);
    OLED_WR_Byte(((x & 0xf0) >> 4) | 0x10, IIC_OLED_CMD);
    OLED_WR_Byte((x & 0x0f), IIC_OLED_CMD);
}

/**************************************************************
 *功  能：开启OLED显示
 *参  数：无
 *返回值：无
 **************************************************************/
void OLED_Display_On(void)
{
    OLED_WR_Byte(0X8D, IIC_OLED_CMD); //SET DCDC命令
    OLED_WR_Byte(0X14, IIC_OLED_CMD); //DCDC ON
    OLED_WR_Byte(0XAF, IIC_OLED_CMD); //DISPLAY ON
}

/**************************************************************
 *功  能：关闭OLED显示
 *参  数：无
 *返回值：无
 **************************************************************/
void OLED_Display_Off(void)
{
    OLED_WR_Byte(0X8D, IIC_OLED_CMD); //SET DCDC命令
    OLED_WR_Byte(0X10, IIC_OLED_CMD); //DCDC OFF
    OLED_WR_Byte(0XAE, IIC_OLED_CMD); //DISPLAY OFF
}

/**************************************************************
 *功  能：清屏函数
 *参  数： 无
 *返回值： 无
 **************************************************************/
void OLED_Clear(void)
{
    uint8_t i, n;
    for (i = 0; i < 8; i++)
    {
        OLED_WR_Byte(0xb0 + i, IIC_OLED_CMD);  //设置页地址（0~7）
        OLED_WR_Byte(0x02, IIC_OLED_CMD);      //设置显示位置—列低地址
        OLED_WR_Byte(0x10, IIC_OLED_CMD);      //设置显示位置—列高地址
        for (n = 0; n < 128; n++)
        {
            OLED_WR_Byte(0x00, IIC_OLED_DATA);
        }
    }
}

/**************************************************************
 *功  能：涂屏函数
 *参  数：byte全屏写同一个字节，写0效果与清屏相同
 *返回值：无
 **************************************************************/
void OLED_Draw(uint8_t byte)
{
    uint8_t i, n;
    for (i = 0; i < 8; i++)
    {
        OLED_WR_Byte(0xb0 + i, IIC_OLED_CMD);  //设置页地址（0~7）
        OLED_WR_Byte(0x02, IIC_OLED_CMD);      //设置显示位置—列低地址
        OLED_WR_Byte(0x10, IIC_OLED_CMD);      //设置显示位置—列高地址
        for (n = 0; n < 128; n++)
        {
            OLED_WR_Byte(byte, IIC_OLED_DATA);
        }
    }
}

/********************************************************
 *功能描述：显示BMP图片128×64
 *参    数：起始点坐标(x0,y0),终点坐标(x1,y1),x的范围0～127，y为页的范围0～7
 *返 回 值：无
 *********************************************************/
void OLED_DrawBMP(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, unsigned char BMP[])
{
    unsigned int j = 0;
    unsigned char x, y;
    if (y1 % 8 == 0)
    {
        y = y1 / 8;
    }
    else
    {
        y = y1 / 8 + 1;
    }
    for (y = y0; y < y1; y++)
    {
        OLED_Set_Pos(x0, y);
        for (x = x0; x < x1; x++)
        {
            OLED_WR_Byte(BMP[j++], IIC_OLED_DATA);
        }
    }
}

/**************************************************************
 *功  能：软件初始化SSD1306
 *参  数：无
 *返回值：无
 **************************************************************/
void OLED_Init(void)
{
    OLED_Hardware_Init();

    rt_thread_mdelay(100);

    OLED_WR_Byte(0xAE, IIC_OLED_CMD); //--turn off oled panel
    OLED_WR_Byte(0x00, IIC_OLED_CMD); //---set low column address
    OLED_WR_Byte(0x10, IIC_OLED_CMD); //---set high column address
    OLED_WR_Byte(0x40, IIC_OLED_CMD); //--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
    OLED_WR_Byte(0x81, IIC_OLED_CMD); //--set contrast control register
    OLED_WR_Byte(0xCF, IIC_OLED_CMD); // Set SEG Output Current Brightness
    OLED_WR_Byte(0xA1, IIC_OLED_CMD); //--Set SEG/Column Mapping     0xa0左右反置 0xa1正常
    OLED_WR_Byte(0xC8, IIC_OLED_CMD); //Set COM/Row Scan Direction   0xc0上下反置 0xc8正常
    OLED_WR_Byte(0xA6, IIC_OLED_CMD); //--set normal display
    OLED_WR_Byte(0xA8, IIC_OLED_CMD); //--set multiplex ratio(1 to 64)
    OLED_WR_Byte(0x3f, IIC_OLED_CMD); //--1/64 duty

    OLED_WR_Byte(0x81, IIC_OLED_CMD);   //对比度设置
    OLED_WR_Byte(0xFF, IIC_OLED_CMD);   //1~255;默认0X7F (亮度设置,越大越亮)

    OLED_WR_Byte(0xD3, IIC_OLED_CMD); //-set display offset   Shift Mapping RAM Counter (0x00~0x3F)
    OLED_WR_Byte(0x00, IIC_OLED_CMD); //-not offset
    OLED_WR_Byte(0xd5, IIC_OLED_CMD); //--set display clock divide ratio/oscillator frequency
    OLED_WR_Byte(0x80, IIC_OLED_CMD); //--set divide ratio, Set Clock as 100 Frames/Sec
    OLED_WR_Byte(0xD9, IIC_OLED_CMD); //--set pre-charge period
    OLED_WR_Byte(0xF1, IIC_OLED_CMD); //Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
    OLED_WR_Byte(0xDA, IIC_OLED_CMD); //--set com pins hardware configuration
    OLED_WR_Byte(0x12, IIC_OLED_CMD);
    OLED_WR_Byte(0xDB, IIC_OLED_CMD); //--set vcomh
    OLED_WR_Byte(0x40, IIC_OLED_CMD); //Set VCOM Deselect Level
    OLED_WR_Byte(0x20, IIC_OLED_CMD); //-Set Page Addressing Mode (0x00/0x01/0x02)
    OLED_WR_Byte(0x02, IIC_OLED_CMD); //
    OLED_WR_Byte(0x8D, IIC_OLED_CMD); //--set Charge Pump enable/disable
    OLED_WR_Byte(0x14, IIC_OLED_CMD); //--set(0x10) disable
    OLED_WR_Byte(0xA4, IIC_OLED_CMD); // Disable Entire Display On (0xa4/0xa5)
    OLED_WR_Byte(0xA6, IIC_OLED_CMD); // Disable Inverse Display On (0xa6/a7)
    OLED_WR_Byte(0xAF, IIC_OLED_CMD); //--turn on oled panel

    OLED_WR_Byte(0xAF, IIC_OLED_CMD); /*display ON*/
    OLED_Clear();
    OLED_Set_Pos(0, 0);
}

/******************************************************************
 函数名：    OLED_ShowChar
 功能：  显示单个英文字符
 参数：  x,y:字符显示位置起始坐标(y需要为8的倍数)
 num:数值（0-94）
 wsize:字体大小
 返回值：    无
 ******************************************************************/
void OLED_ShowChar(uint16_t x, uint16_t y, uint8_t num, uint8_t wsize)
{
    uint8_t pos = 0, t = 0;

    if (wsize != 16)
    {
        //由于库中字符只提供16X8,强制更正显示字符尺寸为16X8
        wsize = 16;
    }

    num = num - ' ';                //得到字符偏移后的值

    //自上到下循环输入
    for (pos = 0; pos < wsize / 8; pos++)
    {
        OLED_Set_Pos(x, y + pos);
        //自左到右循环输入
        for (t = 0; t < wsize / 2; t++)
        {
            OLED_WR_Byte(asc2_1608[num][pos * 8 + t], IIC_OLED_DATA);
        }
    }
}

/******************************************************************
 函数名：    OLED_ShowString
 功能：  显示英文字符串
 参数：  x,y :起点坐标
 *p:字符串起始地址
 wsize:字体大小
 返回值：    无
 ******************************************************************/
void OLED_ShowString(uint16_t x, uint16_t y, char *p, uint8_t wsize)
{
    //判断是不是非法字符
    while ((*p <= '~') && (*p >= ' '))
    {
        //如果x，y坐标超出预设lcd屏大小则换行显示
        if (x > (128 - wsize / 2))
        {
            //显示靠前
            x = 0;
            //显示换行
            y = (y + wsize / 8) % 8;
        }
        if (y > (8 - wsize / 8))
        {
            y = 0;
        }
        //循环显示字串符，坐标（x，y）,使用画笔色和背景色，尺寸和模式由参数决定
        OLED_ShowChar(x, y, *p, wsize);
        //写完一个字符，横坐标加wsize/2
        x += wsize / 2;
        //地址自增
        p++;
    }
}

/******************************************************************
 函数名：    OLED_ShowInt32Num
 功能：  显示数字变量值，非32位的变量可以用强制转换（int32_t）输入数值
 参数：  x,y :起点坐标
 num:数值范围(-2147483648~2147483647)
 len;显示的最少位数，若显示值的长度大于len正常显示，否则补位显示
 wsize:字体大小(12,16)
 返回值：    无
 ******************************************************************/
void OLED_ShowInt32Num(uint16_t x, uint16_t y, int32_t num, uint8_t len, uint8_t wsize)
{
    char show_len[8] = { 0 }, show_num[12] = { 0 };
    uint8_t t = 0;

    if (len > 32)                   //len值过大则退出
        return;
    //len设置最少显示位数，例：输出 %6d
    sprintf(show_len, "%%%dd", (int) len);
    //代入字串符换算，最终完成num2char转换
    sprintf(show_num, show_len, (int) num);

    while (*(show_num + t) != 0)    //循环判断是否为结束符
    {
        //显示字串符的数值
        OLED_ShowChar(x + (wsize / 2) * t, y, show_num[t], wsize);
        //指针偏移地址值自增
        t++;
    }
}

/******************************************************************
 函数名：    OLED_DrawFont16
 功能：  显示单个16X16中文字体
 参数：  x,y :起点坐标
 s:字符串地址
 返回值：    无
 ******************************************************************/
void OLED_DrawFont16(uint16_t x, uint16_t y, char *s)
{
    uint8_t x0 = 0, y0 = 0;
    uint16_t k = 0;
    uint16_t HZnum = 0;

    //自动统计汉字数目
    HZnum = sizeof(tfont16) / sizeof(typFNT_GB16);

    //循环寻找匹配的Index[2]成员值
    for (k = 0; k < HZnum; k++)
    {
        //对应成员值匹配
        if ((tfont16[k].Index[0] == *(s)) && (tfont16[k].Index[1] == *(s + 1)))
        {
            //x方向循环执行写16行，逐行式输入
            for (y0 = 0; y0 < 2; y0++)
            {
                OLED_Set_Pos(x, y + y0);
                //每行写入两个字节，自左到右
                for (x0 = 0; x0 < 16; x0++)
                {
                    //一次写入1字节
                    OLED_WR_Byte(tfont16[k].Msk[y0 * 16 + x0], IIC_OLED_DATA);
                }
            }
            //查找到对应点阵关键字完成绘字后立即break退出for循环，防止多个汉字重复取模显示
            break;
        }
    }
}

/******************************************************************
 函数名：    OLED_DrawFont32
 功能：  显示单个32X32中文字体
 参数：  x,y :起点坐标
 s:字符串地址
 返回值：    无
 ******************************************************************/
void OLED_DrawFont32(uint16_t x, uint16_t y, char *s)
{
    uint8_t x0 = 0, y0 = 0;
    uint16_t k = 0;
    uint16_t HZnum = 0;

    //自动统计汉字数目
    HZnum = sizeof(tfont32) / sizeof(typFNT_GB32);

    //循环寻找匹配的Index[2]成员值
    for (k = 0; k < HZnum; k++)
    {
        //对应成员值匹配
        if ((tfont16[k].Index[0] == *(s)) && (tfont16[k].Index[1] == *(s + 1)))
        {
            //x方向循环执行写16行，逐行式输入
            for (y0 = 0; y0 < 4; y0++)
            {
                OLED_Set_Pos(x, y + y0);
                //每行写入两个字节，自左到右
                for (x0 = 0; x0 < 32; x0++)
                {
                    //一次写入1字节
                    OLED_WR_Byte(tfont32[k].Msk[y0 * 32 + x0], IIC_OLED_DATA);
                }
            }
            //查找到对应点阵关键字完成绘字后立即break退出for循环，防止多个汉字重复取模显示
            break;
        }
    }
}

/******************************************************************
 函数名：    OLED_Show_Str
 功能：  显示一个字符串,包含中英文显示
 参数：  x,y :起点坐标
 str :字符串
 wsize:字体大小
 返回值：    无
 ******************************************************************/
void OLED_Show_Str(uint16_t x, uint16_t y, char *str, uint8_t wsize)
{
    uint16_t x0 = x;
    uint8_t bHz = 0;                //字符或者中文，首先默认是字符

    if (wsize != 32)
        wsize = 16;                 //默认1608
    while (*str != 0)               //判断为否为结束符
    {
        if (!bHz)                   //判断是字符
        {
            //如果x，y坐标超出预设lcd屏大小则换行显示
            if (x > (128 - wsize / 2))
            {
                //显示靠前
                x = 0;
                //显示换行
                y = (y + wsize / 8) % 8;
            }
            if (y > (8 - wsize / 8))
            {
                y = 0;
            }
            if ((uint8_t) *str > 0x80) //对显示的字符检查，判断是否为中文
            {
                bHz = 1;            //判断为中文，则跳过显示字符改为显示中文
            }
            else                    //确定为字符
            {
                if (*str == 0x0D)   //判断是换行符号
                {
                    y += wsize;     //下一个显示的坐标换行
                    x = x0;         //显示靠前
                    str++;          //准备下一个字符
                }
                else                //判断不是换行符
                {
                    //显示对应尺寸字符
                    OLED_ShowChar(x, y, *str, wsize);
                    //显示完后右移起始显示横坐标准备下次显示
                    x += wsize / 2;
                }
                //显示地址自增，准备下一个字符
                str++;
            }
        }
        else                        //判断是中文
        {
            //如果x，y坐标超出预设lcd屏大小则换行显示
            if (x > (128 - wsize))
            {
                //显示靠前
                x = 0;
                //显示换行
                y = (y + wsize / 8) % 8;
            }
            if (y > (8 - wsize / 8))
            {
                y = 0;
            }
            bHz = 0;                //改为默认字符用于下次字符判断
            if (wsize == 32)        //判断是否为32X32大小的中文
                //显示32X32大小的中文
                OLED_DrawFont32(x, y, str);
            else if (wsize == 16)   //否则为16X16大小的中文
                //显示16X16大小的中文
                OLED_DrawFont16(x, y, str);
            //由于显示为中文，需要自增2个地址
            str += 3;
            //显示完后右移起始显示横坐标准备下次显示
            x += wsize;
        }
    }
}

uint8_t OLED_GRAM[128][64];
//更新显存到OLED
void OLED_Refresh(void)
{
    uint8_t i, n, dat[129] = { 0 };
    dat[0] = 0x40;
    for (i = 0; i < 8; i++)
    {
        OLED_WR_Byte(0xb0 + i, 0x00); //设置行起始地址
        OLED_WR_Byte(0x00, 0x00);   //设置低列起始地址
        OLED_WR_Byte(0x10, 0x00);   //设置高列起始地址
        for (n = 0; n < 128; n++)
        {
            dat[n+1] = OLED_GRAM[n][i];
        }
        OLED_WR_Len(dat, 128 + 1);
    }
}
//画点
//x:0~127
//y:0~63
//t:1 填充 0,清空
void OLED_DrawPoint(u8 x, u8 y, u8 t)
{
    u8 i, m, n;
    i = y / 8;
    m = y % 8;
    n = 1 << m;
    if (t)
    {
        OLED_GRAM[x][i] |= n;
    }
    else
    {
        OLED_GRAM[x][i] = ~OLED_GRAM[x][i];
        OLED_GRAM[x][i] |= n;
        OLED_GRAM[x][i] = ~OLED_GRAM[x][i];
    }
}

//画线
//x1,y1:起点坐标
//x2,y2:结束坐标
void OLED_DrawLine(u8 x1, u8 y1, u8 x2, u8 y2, u8 mode)
{
    u16 t;
    int xerr = 0, yerr = 0, delta_x, delta_y, distance;
    int incx, incy, uRow, uCol;
    delta_x = x2 - x1; //计算坐标增量
    delta_y = y2 - y1;
    uRow = x1; //画线起点坐标
    uCol = y1;
    if (delta_x > 0)
        incx = 1; //设置单步方向
    else if (delta_x == 0)
        incx = 0; //垂直线
    else
    {
        incx = -1;
        delta_x = -delta_x;
    }
    if (delta_y > 0)
        incy = 1;
    else if (delta_y == 0)
        incy = 0; //水平线
    else
    {
        incy = -1;
        delta_y = -delta_x;
    }
    if (delta_x > delta_y)
        distance = delta_x; //选取基本增量坐标轴
    else
        distance = delta_y;
    for (t = 0; t < distance + 1; t++)
    {
        OLED_DrawPoint(uRow, uCol, mode); //画点
        xerr += delta_x;
        yerr += delta_y;
        if (xerr > distance)
        {
            xerr -= distance;
            uRow += incx;
        }
        if (yerr > distance)
        {
            yerr -= distance;
            uCol += incy;
        }
    }
}
//x,y:圆心坐标
//r:圆的半径
void OLED_DrawCircle(u8 x, u8 y, u8 r)
{
    int a, b, num;
    a = 0;
    b = r;
    while (2 * b * b >= r * r)
    {
        OLED_DrawPoint(x + a, y - b, 1);
        OLED_DrawPoint(x - a, y - b, 1);
        OLED_DrawPoint(x - a, y + b, 1);
        OLED_DrawPoint(x + a, y + b, 1);

        OLED_DrawPoint(x + b, y + a, 1);
        OLED_DrawPoint(x + b, y - a, 1);
        OLED_DrawPoint(x - b, y - a, 1);
        OLED_DrawPoint(x - b, y + a, 1);

        a++;
        num = (a * a + b * b) - r * r; //计算画的点离圆心的距离
        if (num > 0)
        {
            b--;
            a--;
        }
    }
}



//显示汉字
//x,y:起点坐标
//num:汉字对应的序号
//mode:0,反色显示;1,正常显示
void OLED_ShowChinese(u8 x,u8 y,u8 num,u8 size1,u8 mode)
{
    u8 m,temp;
    u8 x0=x,y0=y;
    u16 i,size3=(size1/8+((size1%8)?1:0))*size1;  //得到字体一个字符对应点阵集所占的字节数
    for(i=0;i<size3;i++)
    {
        if(size1==16)
                {temp=Hzk1[num][i];}//调用16*16字体
        else if(size1==24)
                {temp=Hzk2[num][i];}//调用24*24字体
        else if(size1==32)
                {temp=Hzk3[num][i];}//调用32*32字体
        else if(size1==64)
                {temp=Hzk4[num][i];}//调用64*64字体
        else return;
        for(m=0;m<8;m++)
        {
            if(temp&0x01)OLED_DrawPoint(x,y,mode);
            else OLED_DrawPoint(x,y,!mode);
            temp>>=1;
            y++;
        }
        x++;
        if((x-x0)==size1)
        {x=x0;y0=y0+8;}
        y=y0;
    }
}

//num 显示汉字的个数
//space 每一遍显示的间隔
//mode:0,反色显示;1,正常显示
void OLED_ScrollDisplay(u8 num,u8 space,u8 mode)
{
    u8 i,n,t=0,m=0,r;
    while(1)
    {
        if(m==0)
        {
        OLED_ShowChinese(128,24,t,16,mode); //写入一个汉字保存在OLED_GRAM[][]数组中
            t++;
        }
        if(t==num)
            {
                for(r=0;r<16*space;r++)      //显示间隔
                 {
                    for(i=1;i<144;i++)
                        {
                            for(n=0;n<8;n++)
                            {
                                OLED_GRAM[i-1][n]=OLED_GRAM[i][n];
                            }
                        }
           OLED_Refresh();
                 }
        t=0;
      }
        m++;
        if(m==16){m=0;}
        for(i=1;i<144;i++)   //实现左移
        {
            for(n=0;n<8;n++)
            {
                OLED_GRAM[i-1][n]=OLED_GRAM[i][n];
            }
        }
        OLED_Refresh();
    }
}

#include "all_task.h"
#include "DHT11.h"

#include "actuate/ds1302/ds1302.h"
#include "Ultrasonic.h"

#include "led.h"

#include "beep.h"
// 示例：构造要发送的数据并写入 LCD 设备
//void send_to_nextion_2(rt_device_t lcd_dev, const char* text)
//{
//
//
//    const char* prefix = "page2.t2.txt=\"";
//    const char* suffix = "\"";
//
//
//    size_t prefix_len = strlen(prefix);
//    size_t text_len   = strlen(text);
//    size_t suffix_len = strlen(suffix);
//
//
//    size_t total_len = prefix_len + text_len + suffix_len + 3 /* 0xFF */ + 1 /* '\0' */;
//
//
//    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
//    if (!buffer)
//    {
//        rt_kprintf("malloc failed!\n");
//        return;
//    }
//    memset(buffer, 0, total_len);  // 清零
//
//
//    memcpy(buffer, prefix, prefix_len);
//
//    memcpy(buffer + prefix_len, text, text_len);
//
//    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);
//
//
//    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
//    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
//    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;
//
//
//    buffer[prefix_len + text_len + suffix_len + 3] = '\0';
//
//
//    size_t write_len = prefix_len + text_len + suffix_len + 3;  // 不带末尾 '\0'
//    rt_device_write(lcd_dev, 0, buffer, write_len);
//
//
//    rt_kprintf("Send to Nextion(含0xFFx3): %s\n", buffer);
//
//    rt_free(buffer);
//}


void RW3_thread1(void)
{

    IR_Init();

    while(1)
    {


        if(get_ir_open_tim() == RT_TRUE)
        {
            rt_kprintf("有人!");
            breath_led(PWM_DEVICE_NAME2,PWM_CHANNEL2,500000,400000,20);
        }
        else {
            rt_kprintf("没人!");
            breath_led(PWM_DEVICE_NAME,PWM_CHANNEL,500000,400000,20);
        }

        if (Taskshutdown != 3) {

            LED_RGB_init();

            return;  // 退出任务
        }

        rt_thread_mdelay(1000);
    }
}


void task_3(void)
{

//    LED_RGB_init();
    Taskshutdown = 3;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW3_thread1);

}

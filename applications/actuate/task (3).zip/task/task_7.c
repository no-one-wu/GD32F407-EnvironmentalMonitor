/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"

rt_uint8_t buffer_5[64];
static rt_tick_t start_time = 0; // 全局变量声明

void send_to_nextion_7(rt_device_t lcd_dev, const char *format, ...)
{
    // 定义一个足够大的缓冲区存放格式化后的字符串
    char text_buffer[256];
    va_list args;
    va_start(args, format);
    int n = vsnprintf(text_buffer, sizeof(text_buffer), format, args);
    va_end(args);

    if (n < 0) {
        rt_kprintf("格式化错误！\n");
        return;
    }

    // 构造发送给 Nextion 的完整命令：前缀 + 格式化后的文本 + 后缀 + 3个0xFF结尾
    const char* prefix = "page7.t4.txt=\"";
    const char* suffix = "\"";

    size_t prefix_len = strlen(prefix);
    size_t text_len   = strlen(text_buffer);
    size_t suffix_len = strlen(suffix);

    // 总长度：前缀 + 文本 + 后缀 + 3个0xFF + 1个'\0'
    size_t total_len = prefix_len + text_len + suffix_len + 3 + 1;

    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
    if (!buffer)
    {
        rt_kprintf("内存分配失败!\n");
        return;
    }
    memset(buffer, 0, total_len);

    // 拼接命令：依次复制前缀、格式化后的文本、后缀
    memcpy(buffer, prefix, prefix_len);
    memcpy(buffer + prefix_len, text_buffer, text_len);
    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);

    // 添加 3 个0xFF 作为 Nextion命令结束标志
    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;

    // 最后一个字节置为'\0'
    buffer[prefix_len + text_len + suffix_len + 3] = '\0';

    // 发送数据时不包括最后的'\0'
    size_t write_len = prefix_len + text_len + suffix_len + 3;
    rt_device_write(lcd_dev, 0, buffer, write_len);

    rt_kprintf("Send to Nextion (含0xFFx3): %s\n", buffer);
    rt_free(buffer);
}
void RW7_thread1(void)
{
    Smg_init();  // 初始化蜂鸣器引脚（确保不要同时调用硬件定时器控制）
    rt_tick_t countdown_duration = 100; // 倒计时总时长，单位：秒
    start_time = rt_tick_get() / 1000;    // 记录启动时刻（秒）
    rt_tick_t TIM = 0;
    while(1)
    {
        // 获取当前时间（秒）
        TIM = rt_tick_get() / 1000;
        rt_tick_t elapsed_time = TIM - start_time;
        rt_tick_t remaining_time = (elapsed_time >= countdown_duration) ? 0 : countdown_duration - elapsed_time;

        // 更新数码管显示
        hc595_Test(remaining_time);
        SMG_DRIVE(smg_Refresh_data[0], 1);
        rt_thread_mdelay(12);
        SMG_DRIVE(smg_Refresh_data[1], 2);
        rt_thread_mdelay(12);

        // 当剩余时间小于90秒时，每秒发一次蜂鸣（非阻塞方式）
        if (remaining_time < 90 && remaining_time != 0)
        {
            static rt_tick_t last_beep_time = 0;
            static rt_tick_t beep_start_time = 0;
            static int beep_state = 0;  // 0: 蜂鸣器关闭，1: 蜂鸣器开启
            rt_tick_t now = rt_tick_get();

            // 如果蜂鸣器当前关闭且距离上次蜂鸣超过1秒，则开启蜂鸣
            if (beep_state == 0 && (now - last_beep_time >= rt_tick_from_millisecond(1000))) {
                 BEEP_Control(RT_TRUE);
                 beep_state = 1;
                 beep_start_time = now;
                 last_beep_time = now;
            }
            // 如果蜂鸣器开启且持续时间达到100ms，则关闭蜂鸣
            else if (beep_state == 1 && (now - beep_start_time >= rt_tick_from_millisecond(100))) {
                 BEEP_Control(RT_FALSE);
                 beep_state = 0;
            }
        }

        if (Taskshutdown != 7) {
            SMG_OFF();
            return;  // 退出任务
        }

//        // 添加短延时以确保循环不会过快（不会影响数码管刷新）
//        rt_thread_mdelay(10);
    }
}

void task_7(void)
{




    Taskshutdown = 7;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW7_thread1);

}

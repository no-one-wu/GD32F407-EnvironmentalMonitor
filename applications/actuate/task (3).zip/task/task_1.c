/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"

#include "led.h"
#include "beep.h"



void RW1_thread1(void)
{

    beep_init();

    beep_music(1,500);
    beep_music(2,500);
    beep_music(3,500);
    beep_music(4,500);
    beep_music(5,500);
    beep_music(6,500);
    beep_music(7,500);
    beep_music(0,0);

    while(1)
    {



        if (Taskshutdown != 1) {



            return;  // 退出任务
        }


        rt_thread_mdelay(1000);
    }
}


void task_1(void)
{

//    LED_RGB_init();
    Taskshutdown = 1;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW1_thread1);


}



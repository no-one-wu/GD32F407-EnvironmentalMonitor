/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-02-19     lp666       the first version
 */

#include "all_task.h"
#include "smg.h"



int SMG_1[16] = { 0X3F, 0X06, 0X5B, 0X4F, 0X66, 0X6D, 0X7D, 0X07, 0X7F, 0X6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71 };


unsigned char pattern[5][8] = {
        {0x00,0xFF,0x98,0x94,0x92,0x92,0xF2,0x00},//70
        {0x00,0x4F,0x68,0x44,0x42,0x42,0xE2,0x00},//71
        {0x00,0x6F,0x98,0x94,0x42,0x22,0xF2,0x00},//72
        {0x00,0xEF,0x88,0xE4,0x82,0x82,0xE2,0x00},//73
        {0x00,0x4F,0x68,0x54,0xF2,0x42,0x42,0x00},//74

};
void RW5_thread1(void)
{

    matrix_init();

    while(1)
    {



        Dis_Dynamic_Vertical_TopDown(pattern,5);

        if (Taskshutdown != 5) {

            return;  // 退出任务
        }


    }
}


void task_5(void)
{

    Taskshutdown = 5;
    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW5_thread1);

}

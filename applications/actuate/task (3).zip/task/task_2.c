/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-01-16     lp666       the first version
 */
#include "all_task.h"
#include "DHT11.h"
#include "bkrc_voice.h"
#include "Ultrasonic.h"



// 示例：构造要发送的数据并写入 LCD 设备
void send_to_nextion_2(rt_device_t lcd_dev, const char* text)
{


    const char* prefix = "page2.t2.txt=\"";
    const char* suffix = "\"";


    size_t prefix_len = strlen(prefix);
    size_t text_len   = strlen(text);
    size_t suffix_len = strlen(suffix);


    size_t total_len = prefix_len + text_len + suffix_len + 3 /* 0xFF */ + 1 /* '\0' */;


    rt_uint8_t* buffer = (rt_uint8_t*)rt_malloc(total_len);
    if (!buffer)
    {
        rt_kprintf("malloc failed!\n");
        return;
    }
    memset(buffer, 0, total_len);  // 清零


    memcpy(buffer, prefix, prefix_len);

    memcpy(buffer + prefix_len, text, text_len);

    memcpy(buffer + prefix_len + text_len, suffix, suffix_len);


    buffer[prefix_len + text_len + suffix_len + 0] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 1] = 0xFF;
    buffer[prefix_len + text_len + suffix_len + 2] = 0xFF;


    buffer[prefix_len + text_len + suffix_len + 3] = '\0';


    size_t write_len = prefix_len + text_len + suffix_len + 3;  // 不带末尾 '\0'
    rt_device_write(lcd_dev, 0, buffer, write_len);


    rt_kprintf("Send to Nextion(含0xFFx3): %s\n", buffer);

    rt_free(buffer);
}


static void RW2_thread1(void)
{


    int num_1 = 0;
    Voice_Config_Init();

    voice_rouse();
    rt_thread_mdelay(500);

    unsigned char sum = 0;

    while(1){


        if (Taskshutdown != 2) {

            return;  // 退出任务
        }

        else
        {


            sum =  Voice_Drive();

            rt_kprintf("%d",sum);
            rt_thread_mdelay(700);
            if(sum == 1)
            {

                num_1 = BH1750_Test();
                rt_kprintf("光照强度%d\n",num_1);
                voice_figure(num_1);

            }



        }

        rt_thread_mdelay(1000);

    }
}


void task_2(void)
{
    Taskshutdown = 2;

    rt_mb_send(task1_thread_mailbox,(rt_ubase_t)RW2_thread1);

}
